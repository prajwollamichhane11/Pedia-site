<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <script src="scripts/jquery.min.js"></script>
  <script src="scripts/popper.min.js"></script>
  <script src="scripts/bootstrap.min.js"></script>
  <link rel="stylesheet" href="./css/follow.css">
	<title></title>
</head>
<body>
	<div class="alert alert-success alert-dismissable fade show">
    	<button type="button" class="close" data-dismiss="alert">&times;</button>
    	<strong>You have sucessfully logged in.</strong> 
  	</div>
	<div class="alert alert-primary alert-dismissable fade show">
    	<button type="button" class="close" data-dismiss="alert">&times;</button>
    	<strong>Sucessfully signed up</strong> 
  	</div>
	<div class="alert alert-danger alert-dismissable fade show">
    	<button type="button" class="close" data-dismiss="alert">&times;</button>
    	<strong>Unsucessful</strong> 
  	</div>

</body>
</html>