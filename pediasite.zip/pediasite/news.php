<!DOCTYPE html>
<html lang="en">
<head>
  <title>NEWS</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="./css/stylelog.css">
  <style>
  body {
  background-color: gold;
  -webkit-background-size: 100%;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;
}
  </style>
</head>
<body style="background-color:silver";>
  <?php include("navbar.php");?>
  <br><br><br><br>
    <div class="container">
      <p><h2>This is news section</h2>
      Welcome to the news section. herea re the quick links to most popular health news sites.</p>
    </div>
<div class="container">
  <div class="row">
    <div class="col-md-6">
      <h2>News1</h2>

      <div class="card" style="width:420px">
        <img class="card-img-top" src="img/news1.png" alt="Card image" style="width:400px; height:120px;">
          <div class="card-body">
             <h4 class="card-title">The independent news</h4>
             <p class="card-text">  </p>
             <a href="http://www.independent.co.uk/life-style/health-and-families/health-news" class="btn btn-primary">View full</a>
          </div>
      </div>
    </div>

   <div class="col-md-6">
      <h2>News2</h2>

      <div class="card" style="width:420px">
        <img class="card-img-top" src="img/news2.png" alt="Card image" style="width:400px; height:120px;">
          <div class="card-body">
             <h4 class="card-title">news no 2</h4>
             <p class="card-text"> </p>
             <a href="http://www.bbc.com/news/health" class="btn btn-primary">View Full</a>
          </div>
      </div>
    </div>
  </div>
</div>

<div class="container">
  <div class="row">
    <div class="col-md-6">
      <h2>News1</h2>

      <div class="card" style="width:420px">
        <img class="card-img-top" src="img/news3.png" alt="Card image" style="width:350px; height:100px;">
          <div class="card-body">
             <h4 class="card-title">The independent news</h4>
             <p class="card-text">  </p>
             <a href="https://edition.cnn.com/health" class="btn btn-primary">View full</a>
          </div>
      </div>
    </div>

   <div class="col-md-6">
      <h2>News2</h2>

      <div class="card" style="width:420px">
        <img class="card-img-top" src="img/news4.png" alt="Card image" style="width:400px; height:120px;">
          <div class="card-body">
             <h4 class="card-title">news no 2</h4>
             <p class="card-text"> </p>
             <a href="https://www.medicalnewstoday.com" class="btn btn-primary">View Full</a>
          </div>
      </div>
    </div>
  </div>
</div>

<div class="container">
  <div class="row">
    <div class="col-md-6">
      <h2>News1</h2>

      <div class="card" style="width:420px">
        <img class="card-img-top" src="img/news5.png" alt="Card image" style="width:400px; height:120px;">
          <div class="card-body">
             <h4 class="card-title">The independent news</h4>
             <p class="card-text">  </p>
             <a href="http://www.foxnews.com/health.html" class="btn btn-primary">View full</a>
          </div>
      </div>
    </div>

   <div class="col-md-6">
      <h2>News2</h2>

      <div class="card" style="width:420px">
        <img class="card-img-top" src="img/news6.png" alt="Card image" style="width:400px; height:120px;">
          <div class="card-body">
             <h4 class="card-title">news no 2</h4>
             <p class="card-text"> </p>
             <a href="http://www.firstpost.com/tag/ayurveda" class="btn btn-primary">View Full</a>
          </div>
      </div>
    </div>
  </div>
</div>
<br><br>
<div class="container-fluid">
      <div class="row" style="background-color:#999966;">

      <?php include("footer.php");?>
    </div>
    </div>
</body>
</html>
