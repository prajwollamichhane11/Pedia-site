<html>
<head><title>Contact</title>
  <head>
  <title>navigation</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</head>

<link rel="stylesheet" href="../css/style1.css" />
</head>
<body>
	<! for header>
   <?php include 'navbar.php';?>
   <div class="middle">
       <div>
       	<br><br><br>
       	<p>Your message is sent.</p>
       </div>
   </div>
   <?php //header('location:index.php')?>
   <!for footer>
   <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
   <div class="container-fluid">
      <div class="row" style="background-color:#999966;">
      <?php include("footer.php");?>
    </div>
    </div>
</body>