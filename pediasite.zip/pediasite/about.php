<?php include"navbar.php"?>

<html>
<head>
  <title>navigation</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</head>

<br><br><br>
<title>About Us</title>
<body><center><h3>About Us</h3></center>
	<br><br>

	<div class="container-fluid">
	<h2><center>Welcome to Pediasite</center></h2>
	<div class="row">
		<div class="col-sm-4" style="background-color:lavender;">
			<strong><a href="#"><b><h4><font color="">About US</font></h4></b></a></strong>
			<p style='text-align:justify;'>	
				Pediasite is one of the first health news portal in Nepal that commenced its services with a aim to uplift the health status of people in Nepal.
				At Pediasite, we aim to produce in-depth health related news and articles while also earnestly developing database on pediatricians and hospitals
				profile also other information on field of pediatrics. Initiated by group of four members Pediasite maintains a distinct style of presenting issues
				and thus making it one of the first choice for people searching for health cares on any complications.
			</center>
			</p>
		</div>
		
		<div class="col-sm-1" style="background-color:lavender;"></div>

		<div class="col-sm-3" style="background-color:lavender;">

			<a href="#"><b><h4><font color="">Auto Links</font></h4></b></a>
			<div class="col"><li><a href="index.php"><font color="black">Home</font></a></li></div>
            <div class="col"><li><a href="pediatricians.php"><font color="black">Pediatricians</font></a></li></div>
            <div class="col"><li><a href="hos_id.php"><font color="black">hospitals</font></li></div>
            <div class="col"><li><a href="blog.php"><font color="black">Blog</font></li></div>
            <div class="col"><li><a href="forum.php"><font color="black">Forum</font></li></div>
            <div class="col"><li><a href="contact_us.php"><font color="black">Contact Us</font></li></div>
		</div>
		<div class="col-sm-4" style="background-color:lavender;">
			<a href="#"><b><h4><font color="">Contact US</font></h4></b></a>
			<div class="col"><a href="#"><font color="black"><i class="material-icons" style="font-size:24px">location_on</i>KU Road, Dhulikhel</font></a></div><br>

            <div class="col"><a href="#"><font color="black"><i class="material-icons" style="font-size:24px">call</i>  +977 9841544244 / +977 9845792748</font></a></li></div><br>
            <div class="col"><i class="material-icons" style="font-size:24px">mail</i><font color="black">  prajwollamichhane11@gmail.com</font></div><br>
            <div class="col"><font color="black"><i class="fa fa-globe" style="font-size:24px"></i>  www.prajwollamichhane.com.np</font></div>
           </div>
	</div>
	

	</div>

</body>
<br><br>
<div class="container-fluid">
      <div class="row" style="background-color:#999966;">
      <?php include("footer.php");?>
    </div>
    </div>
</html>
